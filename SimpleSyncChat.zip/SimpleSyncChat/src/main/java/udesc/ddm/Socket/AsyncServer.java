package udesc.ddm.Socket;

import udesc.ddm.Threads.ReceiveMessageThread;
import udesc.ddm.Threads.SendMessageThread;

import java.io.IOException;
import java.net.ServerSocket;

public class AsyncServer extends Server{

    public AsyncServer(ServerSocket server) {
        super(server);
    }

    @Override
    public void serve() throws IOException {
        server.setReuseAddress(true);
        while (true) {
            System.out.println("Waiting connection...");
            connection = server.accept();
            System.out.println("Someone connected");

            setIn();
            setOut();

            ReceiveMessageThread messageReceiver = new ReceiveMessageThread(in);
            SendMessageThread messageSender = new SendMessageThread(out);

                messageReceiver.start();
                messageSender.run();
        }
    }
}
